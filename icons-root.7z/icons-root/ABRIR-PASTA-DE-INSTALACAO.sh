#!/bin/bash

sudo nautilus /usr/share/icons